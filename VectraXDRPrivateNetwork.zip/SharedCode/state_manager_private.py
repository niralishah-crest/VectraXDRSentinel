"""State manager using managed identity for private storage accounts (no public network access)."""
from azure.storage.fileshare import ShareClient, ShareFileClient
from azure.identity import ManagedIdentityCredential
from azure.core.exceptions import ResourceNotFoundError
import os


class StateManager:
    """State manager class for specific operation."""

    def __init__(self, connection_string, file_path, share_name="vectra-checkpoints"):
        """Initialize using managed identity when account name env var is set, else fall back to connection string."""
        account_name = os.environ.get("AzureWebJobsStorage__accountName")
        if account_name:
            credential = ManagedIdentityCredential()
            account_url = f"https://{account_name}.file.core.windows.net"
            self.share_cli = ShareClient(
                account_url=account_url,
                share_name=share_name,
                credential=credential
            )
            self.file_cli = ShareFileClient(
                account_url=account_url,
                share_name=share_name,
                file_path=file_path,
                credential=credential
            )
        else:
            self.share_cli = ShareClient.from_connection_string(
                conn_str=connection_string, share_name=share_name
            )
            self.file_cli = ShareFileClient.from_connection_string(
                conn_str=connection_string, share_name=share_name, file_path=file_path
            )

    def post(self, marker_text: str):
        """Post method for posting the data to azure storage."""
        try:
            self.file_cli.upload_file(marker_text)
        except ResourceNotFoundError:
            self.share_cli.create_share()
            self.file_cli.upload_file(marker_text)

    def get(self):
        """Get method for getting the data from azure storage."""
        try:
            return self.file_cli.download_file().readall().decode()
        except ResourceNotFoundError:
            return None
