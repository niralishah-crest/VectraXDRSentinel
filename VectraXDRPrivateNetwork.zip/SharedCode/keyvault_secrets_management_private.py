"""Key Vault access using ManagedIdentityCredential for private/VNet-integrated deployments.

Uses the function app's system-assigned managed identity to authenticate with Key Vault.
Key Vault must have its public network access disabled and a private endpoint in the same VNet.
The function app's system-assigned managed identity must have the Key Vault Secrets Officer
role assigned on the Key Vault (provisioned by the ARM template).
"""
from azure.keyvault.secrets import SecretClient
from azure.identity import ManagedIdentityCredential
from azure.core.exceptions import ResourceNotFoundError
from ..SharedCode import consts
from ..SharedCode.logger import applogger


class KeyVaultSecretManage:
    """Authenticate with Azure Key Vault via system-assigned managed identity and get or set secrets."""

    def __init__(self) -> None:
        """Initialize Key Vault client using system-assigned managed identity."""
        self.keyvault_name = consts.KEYVAULT_NAME
        if ".us" in consts.SCOPE:
            self.keyvault_uri = "https://{}.vault.usgovcloudapi.net/".format(self.keyvault_name)
        else:
            self.keyvault_uri = "https://{}.vault.azure.net/".format(self.keyvault_name)
        self.client = self._get_client()

    def _get_client(self):
        """Return a SecretClient authenticated via system-assigned ManagedIdentityCredential."""
        credential = ManagedIdentityCredential()
        return SecretClient(vault_url=self.keyvault_uri, credential=credential)

    def get_keyvault_secret(self, secret_name):
        """Get the value of a secret from Key Vault.

        Args:
            secret_name (str): Name of the secret to retrieve.
        """
        try:
            applogger.debug("Retrieving secret {} from {}.".format(secret_name, self.keyvault_name))
            retrieved_secret = self.client.get_secret(secret_name)
            applogger.debug("Retrieved secret value for {}.".format(retrieved_secret.name))
            return retrieved_secret.value
        except ResourceNotFoundError as err:
            applogger.error("Resource not found : '{}' ".format(err))
            self.set_keyvault_secret(secret_name, "")
            return ""

    def set_keyvault_secret(self, secret_name, secret_value):
        """Create or update a secret in Key Vault.

        Args:
            secret_name (str): Name of the secret.
            secret_value (str): Value to store.
        """
        applogger.debug("Creating or updating a secret '{}'.".format(secret_name))
        self.client.set_secret(secret_name, secret_value)
        applogger.debug("Secret created successfully : '{}' .".format(secret_name))

    def get_properties_list_of_secrets(self):
        """Return a list of secret names stored in Key Vault.

        Returns:
            list: Secret names.
        """
        secret_properties = self.client.list_properties_of_secrets()
        return [secret_property.name for secret_property in secret_properties]
