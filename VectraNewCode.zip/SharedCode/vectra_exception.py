"""Vectra Exception Class."""


class VectraException(Exception):
    """Custom Exception Class to handle Vectra Exceptions

    Args:
        Exception (Exception): Inherit from Exception
    """

    def __init__(self, message=None):
        """Initialize custom VectraException with custom message."""
        super().__init__(message)


class VectraIncorrectCredentialsException(Exception):
    """Custom Exception Class to handle Vectra Incorrect Credentials Exceptions

    Args:
        Exception (Exception): Inherit from Exception
    """

    def __init__(self, message=None):
        """Initialize custom VectraIncorrectCredentialsException with custom message."""
        super().__init__(message)
