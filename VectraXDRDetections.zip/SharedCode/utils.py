"""Utility functions for Vectra XDR Data Connector."""

import time
import inspect
import requests
from typing import Callable, Optional, Any, Dict, Set

from SharedCode.logger import applogger
from SharedCode.consts import (
    LOGS_STARTS_WITH,
    DISABLE_FUNCTION_APP_URL,
    RESOURCE_GROUP,
    SUBSCRIPTION_ID,
    FUNCTION_APP_NAME,
    AZURE_AUTHENTICATION_URL,
    AZURE_CLIENT_ID,
    AZURE_CLIENT_SECRET,
    AZURE_AUTHENTICATION_SCOPE,
    AZURE_TENANT_ID,
    STATE_DISABLE_FUNCTION,
    STATE_DISABLE_FUNCTION_COUNT,
)
from SharedCode.exceptions import (
    APIAuthenticationException,
    APIRateLimitException,
    DataConnectorException,
    InvalidResponseException,
)
from SharedCode.state_manager import StateManager

# Default configuration values
DEFAULT_MAX_RETRIES = 3
DEFAULT_BASE_DELAY = 5.0
DEFAULT_MAX_DELAY = 60.0
DEFAULT_EXPONENTIAL_MULTIPLIER = 2.0
RETRYABLE_STATUS_CODES: Set[int] = {429, 500, 502, 503, 504}
NON_RETRYABLE_STATUS_CODES: Set[int] = {400, 403, 404, 409}

# State Manager
state_manager = StateManager(table_name="VectraXDRState")


def calculate_backoff_delay(
    attempt: int,
    base_delay: float = DEFAULT_BASE_DELAY,
    max_delay: float = DEFAULT_MAX_DELAY,
    multiplier: float = DEFAULT_EXPONENTIAL_MULTIPLIER,
) -> float:
    """
    Calculate exponential backoff delay for a given attempt.

    Args:
        attempt: Current attempt number (1-indexed).
        base_delay: Initial delay in seconds.
        max_delay: Maximum delay cap in seconds.
        multiplier: Exponential multiplier.

    Returns:
        Delay in seconds.
    """
    delay = base_delay * (multiplier ** (attempt - 1))
    return min(delay, max_delay)


def is_retryable_status_code(status_code: int) -> bool:
    """
    Check if HTTP status code should trigger a retry.

    Args:
        status_code: HTTP status code.

    Returns:
        True if the status code is retryable (429, 5xx).
    """
    return status_code in RETRYABLE_STATUS_CODES


def is_non_retryable_status_code(status_code: int) -> bool:
    """
    Check if HTTP status code should NOT be retried.

    Args:
        status_code: HTTP status code.

    Returns:
        True if the status code should fail immediately (400, 403, 404, 409).
    """
    return status_code in NON_RETRYABLE_STATUS_CODES


def raise_for_status_code(
    status_code: int,
    response_text: str,
    operation_name: str = "API request",
) -> None:
    """
    Raise appropriate exception for non-retryable status codes.

    Args:
        status_code: HTTP status code.
        response_text: Response body text.
        operation_name: Name of the operation for error messages.

    Raises:
        APIAuthenticationException: For 403 Forbidden.
        InvalidResponseException: For 400, 404, 409, and other client errors.
    """
    __method_name = inspect.currentframe().f_code.co_name
    logs_starts_with = f"{LOGS_STARTS_WITH} {__method_name}:"
    truncated_text = response_text[:500] if response_text else "No response body"

    error_handlers = {
        400: (InvalidResponseException, f"Bad request: {truncated_text}"),
        403: (APIAuthenticationException, f"Access forbidden: {truncated_text}"),
        404: (InvalidResponseException, f"Resource not found: {truncated_text}"),
        409: (InvalidResponseException, f"Conflict error: {truncated_text}"),
    }

    if status_code in error_handlers:
        exception_class, message = error_handlers[status_code]
        applogger.error(
            f"{logs_starts_with} {operation_name} failed ({status_code}): {truncated_text}"
        )
        raise exception_class(message)

    # Generic error
    applogger.error(
        f"{logs_starts_with} {operation_name} failed with status {status_code}: {truncated_text}"
    )
    raise InvalidResponseException(
        f"Request failed with status {status_code}: {truncated_text}"
    )


def _execute_http_request(
    session: requests.Session,
    method: str,
    url: str,
    headers: Dict[str, str],
    params: Optional[Dict[str, Any]] = None,
    data: Optional[Dict[str, Any]] = None,
    timeout: int = 60,
) -> requests.Response:
    """
    Execute a single HTTP request.

    Args:
        session: Requests session object.
        method: HTTP method.
        url: Full URL.
        headers: Request headers.
        params: Query parameters.
        data: Request body.
        timeout: Request timeout.

    Returns:
        Response object.
    """
    return session.request(
        method=method,
        url=url,
        headers=headers,
        params=params,
        json=data,
        timeout=timeout,
    )


def make_request_with_retry(
    session: requests.Session,
    method: str,
    url: str,
    headers_func: Callable[[], Dict[str, str]],
    params: Optional[Dict[str, Any]] = None,
    data: Optional[Dict[str, Any]] = None,
    timeout: int = 60,
    operation_name: str = "API request",
    max_retries: int = DEFAULT_MAX_RETRIES,
    base_delay: float = DEFAULT_BASE_DELAY,
    max_delay: float = DEFAULT_MAX_DELAY,
    token_refresher: Optional[Callable[[], bool]] = None,
    function_name: str = None,
) -> requests.Response:
    """
    Execute an HTTP request with retry logic.

    Retry behavior:
    - 401: Refresh tokens and retry once (if token_refresher provided)
    - 429, 5xx: Retry with exponential backoff up to max_retries
    - ConnectionError, Timeout: Retry with exponential backoff
    - 400, 403, 404, 409: Fail immediately (no retry)

    Args:
        session: Requests session object.
        method: HTTP method.
        url: Full URL.
        headers_func: Function that returns current headers (for token refresh).
        params: Query parameters.
        data: Request body.
        timeout: Request timeout.
        operation_name: Name of the operation for logging.
        max_retries: Maximum number of retry attempts.
        base_delay: Base delay for exponential backoff in seconds.
        max_delay: Maximum delay cap in seconds.
        token_refresher: Optional function to refresh tokens on 401.
        function_name: Function name for checkpoint tracking.

    Returns:
        The successful Response object.

    Raises:
        APIAuthenticationException: On authentication failures.
        APIRateLimitException: When rate limit retries are exhausted.
        InvalidResponseException: On non-retryable client errors.
        DataConnectorException: On other failures after retries exhausted.
    """
    __method_name = inspect.currentframe().f_code.co_name
    logs_starts_with = f"{LOGS_STARTS_WITH} {__method_name}:"

    last_exception: Optional[Exception] = None
    last_response: Optional[requests.Response] = None
    token_refreshed = False

    for attempt in range(1, max_retries + 1):
        try:
            applogger.debug(
                f"{logs_starts_with} {operation_name} - Attempt {attempt}/{max_retries}"
            )

            # Get fresh headers (important after token refresh)
            headers = headers_func()
            
            # Execute request
            response = _execute_http_request(
                session, method, url, headers, params, data, timeout
            )
            status_code = response.status_code

            # Success (2xx)
            if 200 <= status_code < 300:
                if attempt > 1:
                    applogger.info(
                        f"{logs_starts_with} {operation_name} succeeded on attempt {attempt}."
                    )
                update_checkpoint_of_disabling_function(function_name, make_count_zero=True)
                return response

            # Handle 401 - token refresh and single retry
            if status_code == 401 and not token_refreshed:
                if token_refresher:
                    applogger.info(
                        f"{logs_starts_with} Received 401 for {operation_name}. Refreshing tokens."
                    )
                    try:
                        if not token_refresher():
                            raise APIAuthenticationException("Token refresh returned failure.")
                        token_refreshed = True
                        applogger.info(f"{logs_starts_with} Tokens refreshed. Retrying request.")
                        continue  # Retry with new tokens
                    except APIAuthenticationException:
                        raise
                    except Exception as err:
                        applogger.error(f"{logs_starts_with} Token refresh failed: {err}")
                        raise APIAuthenticationException(f"Failed to refresh tokens: {err}") from err
                else:
                    applogger.error(
                        f"{logs_starts_with} Received 401 but no token refresher configured."
                    )
                    update_checkpoint_of_disabling_function(function_name)
                    raise APIAuthenticationException(
                        "Authentication failed. No token refresh mechanism available."
                    )
            elif status_code == 401 and token_refreshed:
                # Already refreshed once, still getting 401
                applogger.error(
                    f"{logs_starts_with} {operation_name} still failed with 401 after token refresh."
                )
                update_checkpoint_of_disabling_function(function_name)
                raise APIAuthenticationException(
                    "Authentication failed after token refresh. Credentials may be invalid."
                )

            # Non-retryable errors - fail immediately
            if is_non_retryable_status_code(status_code):
                raise_for_status_code(status_code, response.text, operation_name)

            # Retryable errors - continue retry loop
            if is_retryable_status_code(status_code):
                last_response = response
                applogger.warning(
                    f"{logs_starts_with} {operation_name} received status {status_code}. "
                    f"Attempt {attempt}/{max_retries}."
                )
                if attempt < max_retries:
                    delay = calculate_backoff_delay(attempt, base_delay, max_delay)
                    applogger.info(
                        f"{logs_starts_with} Waiting {delay:.2f}s before retry."
                    )
                    time.sleep(delay)
                continue

            # Unknown status code - treat as non-retryable
            raise_for_status_code(status_code, response.text, operation_name)

        except (
            requests.exceptions.ConnectionError,
            requests.exceptions.Timeout,
        ) as err:
            last_exception = err
            applogger.warning(
                f"{logs_starts_with} {operation_name} network error: {type(err).__name__}. "
                f"Attempt {attempt}/{max_retries}."
            )
            if attempt < max_retries:
                delay = calculate_backoff_delay(attempt, base_delay, max_delay)
                applogger.info(f"{logs_starts_with} Waiting {delay:.2f}s before retry.")
                time.sleep(delay)
            continue

        except requests.exceptions.RequestException as err:
            applogger.error(f"{logs_starts_with} {operation_name} request error: {err}")
            raise DataConnectorException(f"Request failed: {err}") from err

    # All retries exhausted
    _handle_retries_exhausted(
        last_response, last_exception, operation_name, max_retries
    )


def _handle_retries_exhausted(
    last_response: Optional[requests.Response],
    last_exception: Optional[Exception],
    operation_name: str,
    max_retries: int,
) -> None:
    """
    Handle the case when all retries are exhausted.

    Args:
        last_response: The last response received (if any).
        last_exception: The last exception caught (if any).
        operation_name: Name of the operation.
        max_retries: Number of retries attempted.

    Raises:
        APIRateLimitException: If last failure was rate limiting.
        DataConnectorException: For other failures.
    """
    __method_name = inspect.currentframe().f_code.co_name
    logs_starts_with = f"{LOGS_STARTS_WITH} {__method_name}:"

    if last_response is not None:
        status_code = last_response.status_code
        if status_code == 429:
            applogger.error(
                f"{logs_starts_with} {operation_name} rate limit exceeded after {max_retries} attempts."
            )
            raise APIRateLimitException(
                f"Rate limit exceeded after {max_retries} retries."
            )

        applogger.error(
            f"{logs_starts_with} {operation_name} failed with status {status_code} after {max_retries} attempts."
        )
        raise DataConnectorException(
            f"Request failed with status {status_code} after {max_retries} retries."
        )

    if last_exception is not None:
        applogger.error(
            f"{logs_starts_with} {operation_name} failed with {type(last_exception).__name__} "
            f"after {max_retries} attempts: {last_exception}"
        )
        raise DataConnectorException(
            f"Request failed after {max_retries} retries: {last_exception}"
        ) from last_exception

    raise DataConnectorException(
        f"{operation_name} failed after {max_retries} retries."
    )


def chunk_list(data: list, chunk_size: int) -> list:
    """
    Split a list into chunks of specified size.

    Args:
        data: List to split.
        chunk_size: Maximum size of each chunk.

    Returns:
        List of chunks.
    """
    return [data[i : i + chunk_size] for i in range(0, len(data), chunk_size)]


def get_payload_size_mb(data: Any) -> float:
    """
    Calculate approximate size of data in megabytes.

    Args:
        data: Data to measure (will be JSON serialized).

    Returns:
        Size in megabytes.
    """
    import json

    json_str = json.dumps(data)
    return len(json_str.encode("utf-8")) / (1024 * 1024)


def truncate_large_field(value: str, max_size_kb: int = 25) -> str:
    """
    Truncate a string field if it exceeds max size.

    Args:
        value: String value to potentially truncate.
        max_size_kb: Maximum size in kilobytes (default 25KB for Sentinel limit).

    Returns:
        Original or truncated string.
    """
    max_bytes = max_size_kb * 1024
    encoded = value.encode("utf-8")
    if len(encoded) <= max_bytes:
        return value

    # Truncate and add indicator
    truncated = encoded[: max_bytes - 50].decode("utf-8", errors="ignore")
    return f"{truncated}... [TRUNCATED]"


def sanitize_column_name(name: str) -> str:
    """
    Sanitize a column name for Azure Log Analytics.

    Rules:
    - Must start with a letter
    - Max 45 characters
    - Only alphanumeric and underscore

    Args:
        name: Original column name.

    Returns:
        Sanitized column name.
    """
    import re

    # Remove invalid characters
    sanitized = re.sub(r"[^a-zA-Z0-9_]", "_", name)

    # Ensure starts with letter
    if sanitized and not sanitized[0].isalpha():
        sanitized = f"col_{sanitized}"

    # Truncate to 45 characters
    return sanitized[:45]


def disable_function(function_name):
    """
    Disable a function app as failure count reached to 10.

    Disable the function app by sending a POST request to the function app URL.

    Args:
        function_name (str): The name of the function to disable.

    Raises:
        DataConnectorException: If any error occurs while disabling the function.
        requests.exceptions.HTTPError: If the POST request to disable the function fails.
        Exception: If any other error occurs.
    """
    try:
        __method_name = inspect.currentframe().f_code.co_name
        url = (DISABLE_FUNCTION_APP_URL).format(
            SUBSCRIPTION_ID, RESOURCE_GROUP, FUNCTION_APP_NAME
        )

        access_token = azure_token_generator(function_name)
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.post(url=url, headers=headers)

        response.raise_for_status()
        if response.status_code in [200, 201]:
            applogger.info(
                "{}(method={}): {}: Function App disabled successfully.".format(
                    LOGS_STARTS_WITH, __method_name, function_name
                )
            )
        else:
            applogger.error(
                "{}(method={}): {}: Error occurred while disabling function. status_code={}, reason={}".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    function_name,
                    response.status_code,
                    response.text,
                )
            )
            raise DataConnectorException()
    except DataConnectorException:
        raise DataConnectorException()
    except requests.exceptions.HTTPError as err:
        applogger.error(
            "{}(method={}): {}: Error occurred while disabling function : status code: {}, reason: '{}'.".format(
                LOGS_STARTS_WITH,
                __method_name,
                function_name,
                response.status_code,
                err,
            )
        )
        # ! Save state to disable function -> confirm @Nirali
        state_manager.save_state(STATE_DISABLE_FUNCTION, False)
        raise DataConnectorException()
    except Exception as err:
        applogger.error(
            "{}(method={}): {}: Error occured while disabling function : '{}'.".format(
                LOGS_STARTS_WITH, __method_name, function_name, err
            )
        )
        # ! Save state to disable function -> confirm @Nirali
        state_manager.save_state(STATE_DISABLE_FUNCTION, False)
        raise DataConnectorException()


def azure_token_generator(function_name):
    """
    Generate access token for azure.

    Args:
        function_name: The name of the function that is calling this function.

    Returns:
        The access token for Azure.

    Raises:
        DataConnectorException: If there is an error while generating the access token.
    """
    try:
        __method_name = inspect.currentframe().f_code.co_name
        url = AZURE_AUTHENTICATION_URL.format(AZURE_TENANT_ID)

        data = {
            "client_id": AZURE_CLIENT_ID,
            "client_secret": AZURE_CLIENT_SECRET,
            "grant_type": "client_credentials",
            "scope": AZURE_AUTHENTICATION_SCOPE,
        }

        response = requests.get(url=url, data=data)
        if response.status_code in [200, 201]:
            applogger.info(
                "{}(method={}): {}: Azure Token Generated Successfully.".format(
                    LOGS_STARTS_WITH, __method_name, function_name
                )
            )
            return response.json()["access_token"]
        else:
            applogger.error(
                "{}(method={}): {}: Unknown Status code while generating access token for AZURE: {} .".format(
                    LOGS_STARTS_WITH, __method_name, function_name, response.status_code
                )
            )
            # Does it really needed -> as disable function app access token fails, what is the need of updating checkpoint -> does not make sense to me
            # ! Save state to disable function -> confirm @Nirali
            state_manager.save_state(STATE_DISABLE_FUNCTION, False)
            raise DataConnectorException()
    except DataConnectorException:
        raise DataConnectorException()
    except Exception as err:
        applogger.info(
            "{}(method={}): {}: Error occured while generating access token for AZURE: {}.".format(
                LOGS_STARTS_WITH, __method_name, function_name, err
            )
        )
        # ! Save state to disable function -> confirm @Nirali
        state_manager.save_state(STATE_DISABLE_FUNCTION, False)
        raise DataConnectorException()


def update_checkpoint_of_disabling_function(function_name, make_count_zero=False):
    """Update checkpoint file for disabling function.

    Args:
        make_count_zero (bool): True when count of status code should be made zero

    Raises:
        Exception: if anything goes unintended
    """
    try:
        __method_name = inspect.currentframe().f_code.co_name
        # Checkpoint fetch logic needs to be updated based on state manager
        disable_function_flag = state_manager.get_state(STATE_DISABLE_FUNCTION)
        disable_function_count = state_manager.get_state(STATE_DISABLE_FUNCTION_COUNT)
        if disable_function_flag is not True:
            disable_function_flag = False
        if disable_function_count is None:
            disable_function_count = 0
        # Assuming disable_function_flag is true only when count exceeds 10
        # ! need of this if condition -> confirm @Nirali
        # if disable_function_flag:
        #     checkpoint_json_data.update(
        #         {"disable_function": False, "status_code_count": 0}
        #     )
        #     disable_function_flag = False
        #     state_manager.save_state(STATE_DISABLE_FUNCTION, disable_function_flag)
        #     state_manager.save_state(STATE_DISABLE_FUNCTION_COUNT, 0)
        if make_count_zero:
            if disable_function_count != 0:
                # checkpoint_json_data.update({"status_code_count": 0})
                # state_manager.save_state(STATE_DISABLE_FUNCTION, disable_function_flag)
                state_manager.save_state(STATE_DISABLE_FUNCTION_COUNT, 0)
                applogger.debug(
                    "{}(method={}): {}: Checkpoint file updated as total count of status code made zero.".format(
                        LOGS_STARTS_WITH, __method_name, function_name
                    )
                )
            else:
                applogger.debug(
                    "{}(method={}): {}: Checkpoint file already have total count of status code equal to zero.".format(
                        LOGS_STARTS_WITH, __method_name, function_name
                    )
                )
        else:
            current_count = disable_function_count
            updated_status_code_count = current_count + 1
            if updated_status_code_count >= 10:
                applogger.info(
                    "{}(method={}): {}: Disabling Function App...".format(
                        LOGS_STARTS_WITH, __method_name, function_name
                    )
                )
                state_manager.save_state(STATE_DISABLE_FUNCTION, True)
                state_manager.save_state(
                    STATE_DISABLE_FUNCTION_COUNT, updated_status_code_count
                )
                disable_function(function_name)
                return

            state_manager.save_state(
                STATE_DISABLE_FUNCTION_COUNT, updated_status_code_count
            )
            applogger.debug(
                "{}(method={}): {}: Updated failed status code count in checkpoint file.".format(
                    LOGS_STARTS_WITH, __method_name, function_name
                )
            )
    except DataConnectorException:
        raise DataConnectorException()
    except Exception as err:
        applogger.error(
            "{}(method={}): {}: Error Occured while updating checkpoint file of disabling function. : '{}'".format(
                LOGS_STARTS_WITH, __method_name, function_name, err
            )
        )

        raise DataConnectorException()


# ============================================================================
# Token Management Functions
# ============================================================================


def load_tokens_to_memory(
    kv_manager,
    state_manager,
    access_token_expiry_key: str,
    refresh_token_expiry_key: str,
) -> Dict[str, Any]:
    """
    Load tokens from Key Vault and expiry times from Table Storage into memory.
    Called once during initialization to cache tokens for the execution.

    Args:
        kv_manager: KeyVaultManager instance.
        state_manager: StateManager instance.
        access_token_expiry_key: State key for access token expiry.
        refresh_token_expiry_key: State key for refresh token expiry.

    Returns:
        Dictionary containing:
        - access_token: Access token string or None
        - refresh_token: Refresh token string or None
        - access_token_expiry: Expiry timestamp or None
        - refresh_token_expiry: Expiry timestamp or None
    """
    __method_name = inspect.currentframe().f_code.co_name
    logs_starts_with = f"{LOGS_STARTS_WITH} {__method_name}:"

    token_cache = {
        "access_token": None,
        "refresh_token": None,
        "access_token_expiry": None,
        "refresh_token_expiry": None,
    }

    try:
        # Load tokens from Key Vault
        token_cache["access_token"] = kv_manager.get_access_token()
        token_cache["refresh_token"] = kv_manager.get_refresh_token()

        # Load expiry times from Table Storage
        access_expiry = state_manager.get_state(access_token_expiry_key)
        refresh_expiry = state_manager.get_state(refresh_token_expiry_key)

        # Convert to float if present
        if access_expiry:
            try:
                token_cache["access_token_expiry"] = float(access_expiry)
            except (ValueError, TypeError):
                token_cache["access_token_expiry"] = None

        if refresh_expiry:
            try:
                token_cache["refresh_token_expiry"] = float(refresh_expiry)
            except (ValueError, TypeError):
                token_cache["refresh_token_expiry"] = None

        applogger.debug(
            f"{logs_starts_with} Tokens loaded to memory. "
            f"Access token: {'present' if token_cache['access_token'] else 'missing'}, "
            f"Refresh token: {'present' if token_cache['refresh_token'] else 'missing'}"
        )
    except Exception as err:
        applogger.warning(
            f"{logs_starts_with} Error loading tokens to memory: {err}"
        )

    return token_cache


def store_tokens(
    data: Dict[str, Any],
    kv_manager,
    state_manager,
    access_token_expiry_key: str,
    refresh_token_expiry_key: str,
    token_cache: Dict[str, Any],
) -> None:
    """
    Store tokens from authentication response in Key Vault, state table, and in-memory cache.

    Args:
        data: Response data containing tokens and expiry information.
        kv_manager: KeyVaultManager instance.
        state_manager: StateManager instance.
        access_token_expiry_key: State key for access token expiry.
        refresh_token_expiry_key: State key for refresh token expiry.
        token_cache: Dictionary to update with new token values.
    """
    __method_name = inspect.currentframe().f_code.co_name
    logs_starts_with = f"{LOGS_STARTS_WITH} {__method_name}:"

    # Extract tokens
    access_token = data.get("access_token")
    refresh_token = data.get("refresh_token")
    expires_in = data.get("expires_in")
    refresh_expires_in = data.get("refresh_expires_in")

    # Store tokens in Key Vault
    if access_token:
        kv_manager.set_access_token(access_token)
        token_cache["access_token"] = access_token  # Update in-memory cache
    if refresh_token:
        kv_manager.set_refresh_token(refresh_token)
        token_cache["refresh_token"] = refresh_token  # Update in-memory cache

    # Calculate and store expiry timestamps in state table and memory
    current_time = time.time()

    if expires_in:
        # Set expiration with 60-second buffer
        access_token_expiry = current_time + expires_in - 60
        state_manager.save_state(access_token_expiry_key, access_token_expiry)
        token_cache["access_token_expiry"] = access_token_expiry  # Update in-memory cache
        applogger.debug(
            f"{logs_starts_with} Access token expiry saved: {access_token_expiry}"
        )

    if refresh_expires_in:
        refresh_token_expiry = current_time + refresh_expires_in - 60
        state_manager.save_state(refresh_token_expiry_key, refresh_token_expiry)
        token_cache["refresh_token_expiry"] = refresh_token_expiry  # Update in-memory cache
        applogger.debug(
            f"{logs_starts_with} Refresh token expiry saved: {refresh_token_expiry}"
        )


def is_access_token_expired(token_cache: Dict[str, Any]) -> bool:
    """
    Check if the current access token has expired using in-memory cache.

    Args:
        token_cache: Dictionary containing token and expiry information.

    Returns:
        True if token is expired or not set.
    """
    # Check if access token exists in memory
    if not token_cache.get("access_token"):
        return True

    # Check expiry from in-memory cache
    access_token_expiry = token_cache.get("access_token_expiry")
    if access_token_expiry:
        if time.time() >= access_token_expiry:
            return True

    return False


def is_refresh_token_expired(token_cache: Dict[str, Any]) -> bool:
    """
    Check if the current refresh token has expired using in-memory cache.

    Args:
        token_cache: Dictionary containing token and expiry information.

    Returns:
        True if token is expired or not set.
    """
    # Check if refresh token exists in memory
    if not token_cache.get("refresh_token"):
        return True

    # Check expiry from in-memory cache
    refresh_token_expiry = token_cache.get("refresh_token_expiry")
    if refresh_token_expiry:
        if time.time() >= refresh_token_expiry:
            return True

    return False


def perform_oauth_request(
    grant_type: str,
    base_url: str,
    client_id: str,
    client_secret: str,
    session: requests.Session,
    kv_manager,
    state_manager,
    access_token_expiry_key: str,
    refresh_token_expiry_key: str,
    token_cache: Dict[str, Any],
    refresh_token: Optional[str] = None,
    function_name: str = None,
) -> None:
    """
    Perform OAuth token request with the specified grant type.
    Uses HTTP Basic Authentication for client_id and client_secret.

    Args:
        grant_type: OAuth grant type ('client_credentials' or 'refresh_token').
        base_url: Base URL for the API.
        client_id: OAuth client ID.
        client_secret: OAuth client secret.
        session: Requests session object.
        kv_manager: KeyVaultManager instance.
        state_manager: StateManager instance.
        access_token_expiry_key: State key for access token expiry.
        refresh_token_expiry_key: State key for refresh token expiry.
        token_cache: Dictionary to update with new token values.
        refresh_token: Required when grant_type is 'refresh_token'.
        function_name: Name of the function for logging.

    Raises:
        APIAuthenticationException: If authentication fails.
    """
    __method_name = inspect.currentframe().f_code.co_name
    logs_starts_with = f"{LOGS_STARTS_WITH} {__method_name}:"

    # Log appropriate message based on grant type
    if grant_type == "client_credentials":
        applogger.info(
            f"{logs_starts_with} Authenticating with client credentials."
        )
        operation_name = "Authentication"
    else:  # refresh_token
        applogger.info(
            f"{logs_starts_with} Refreshing access token using refresh token."
        )
        operation_name = "Token refresh"
        if not refresh_token:
            applogger.warning(
                f"{logs_starts_with} No refresh token available."
            )
            raise APIAuthenticationException("No refresh token available.")

    auth_url = f"{base_url}/oauth2/token"
    payload = {"grant_type": grant_type}

    # Add refresh_token to payload if using refresh_token grant
    if grant_type == "refresh_token" and refresh_token:
        payload["refresh_token"] = refresh_token

    try:
        # Use HTTP Basic Authentication for client credentials
        response = session.post(
            auth_url,
            data=payload,
            auth=(client_id, client_secret),
            timeout=30
        )

        if response.status_code == 200:
            response_data = response.json()
            store_tokens(
                response_data,
                kv_manager,
                state_manager,
                access_token_expiry_key,
                refresh_token_expiry_key,
                token_cache
            )
            # Added by @Shashank
            update_checkpoint_of_disabling_function(function_name=function_name, make_count_zero=True)
            applogger.info(
                f"{logs_starts_with} {operation_name} successful."
            )
        elif response.status_code == 401:
            update_checkpoint_of_disabling_function(function_name=function_name)
            error_msg = "Invalid credentials." if grant_type == "client_credentials" else "Refresh token invalid or expired."
            if grant_type == "refresh_token":
                applogger.warning(
                    f"{logs_starts_with} {error_msg}"
                )
            raise APIAuthenticationException(error_msg)
        else:
            raise APIAuthenticationException(
                f"{operation_name} failed with status {response.status_code}: {response.text}"
            )

    except APIAuthenticationException:
        raise
    except requests.exceptions.Timeout as err:
        applogger.error(
            f"{logs_starts_with} Request timeout: {err}"
        )
        raise APIAuthenticationException(f"{operation_name} timeout: {err}") from err
    except requests.exceptions.ConnectionError as err:
        applogger.error(
            f"{logs_starts_with} Connection error: {err}"
        )
        raise APIAuthenticationException(
            f"{operation_name} connection error: {err}"
        ) from err
    except requests.exceptions.RequestException as err:
        applogger.error(
            f"{logs_starts_with} Request error: {err}"
        )
        raise APIAuthenticationException(
            f"{operation_name} request failed: {err}"
        ) from err


def authenticate_with_vectra_api(
    base_url: str,
    client_id: str,
    client_secret: str,
    session: requests.Session,
    kv_manager,
    state_manager,
    access_token_expiry_key: str,
    refresh_token_expiry_key: str,
    token_cache: Dict[str, Any],
    function_name: str = None,
) -> None:
    """
    Authenticate with the Vectra XDR API.

    Logic:
    - If access token is expired or missing:
      - If refresh token is valid: Use refresh token to get new access token
      - If refresh token is expired/missing: Use client credentials

    Args:
        base_url: Base URL for the API.
        client_id: OAuth client ID.
        client_secret: OAuth client secret.
        session: Requests session object.
        kv_manager: KeyVaultManager instance.
        state_manager: StateManager instance.
        access_token_expiry_key: State key for access token expiry.
        refresh_token_expiry_key: State key for refresh token expiry.
        token_cache: Dictionary containing token and expiry information.
        function_name: Name of the function for logging.

    Raises:
        APIAuthenticationException: If authentication fails.
    """
    __method_name = inspect.currentframe().f_code.co_name
    logs_starts_with = f"{LOGS_STARTS_WITH} {__method_name}:"

    # Check if access token is expired
    if not is_access_token_expired(token_cache):
        applogger.debug(
            f"{logs_starts_with} Access token is still valid."
        )
        return

    applogger.info(
        f"{logs_starts_with} Access token expired or missing."
    )

    # Check if refresh token is available and valid
    if not is_refresh_token_expired(token_cache):
        applogger.info(
            f"{logs_starts_with} Refresh token is valid. Using refresh token."
        )
        try:
            perform_oauth_request(
                grant_type="refresh_token",
                base_url=base_url,
                client_id=client_id,
                client_secret=client_secret,
                session=session,
                kv_manager=kv_manager,
                state_manager=state_manager,
                access_token_expiry_key=access_token_expiry_key,
                refresh_token_expiry_key=refresh_token_expiry_key,
                token_cache=token_cache,
                refresh_token=token_cache.get("refresh_token"),
                function_name=function_name
            )
            return
        except APIAuthenticationException as err:
            applogger.warning(
                f"{logs_starts_with} "
                f"Refresh token authentication failed: {err}. Falling back to client credentials."
            )

    # Fall back to client credentials
    applogger.info(
        f"{logs_starts_with} Using client credentials authentication."
    )
    perform_oauth_request(
        grant_type="client_credentials",
        base_url=base_url,
        client_id=client_id,
        client_secret=client_secret,
        session=session,
        kv_manager=kv_manager,
        state_manager=state_manager,
        access_token_expiry_key=access_token_expiry_key,
        refresh_token_expiry_key=refresh_token_expiry_key,
        token_cache=token_cache,
        function_name=function_name
    )
